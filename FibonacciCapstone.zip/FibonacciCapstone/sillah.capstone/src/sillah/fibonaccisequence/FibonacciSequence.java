package sillah.fibonaccisequence;

import javax.swing.JOptionPane;

public class FibonacciSequence
{

	public FibonacciSequence()
	{
		String userInput;
		while (true)
		{
			userInput = startMenu();

			if (userInput.equalsIgnoreCase("Calculate"))
			{
				displayFibonacciNumbers(fibonacciNumbersOutputString(fibonacciFormula()));
			} else if (userInput.equalsIgnoreCase("Exit"))
			{
				System.exit(0);
			} else
			{
				invalidInputDisplay();
			}
		}
	}

	public void invalidInputDisplay()
	{
		JOptionPane.showMessageDialog(null, "Your input was invalid. ");
	}

	public String startMenu()
	{
		String userInput;

		userInput = JOptionPane.showInputDialog(
				"Would you like to calculate the first Fibonacci numbers or exit the program? If yes, type in 'calculate' if no type in 'exit' .");

		return userInput;
	}

	public long[] fibonacciFormula()
	{
		long fibonacciNumbers[] = new long[50];
		long firstTerm = 0;
		long secondTerm = 1;
		fibonacciNumbers[0] = 0;

		for (int count = 1; count < fibonacciNumbers.length; count++)
		{
			fibonacciNumbers[count] = firstTerm + secondTerm;

			firstTerm = secondTerm;

			secondTerm = fibonacciNumbers[count];

		}
		return fibonacciNumbers;

	}

	public void displayFibonacciNumbers(String fibonacciNumbersAsString)
	{
		JOptionPane.showMessageDialog(null, fibonacciNumbersAsString);
	}

	public String fibonacciNumbersOutputString(long[] fibonacciNumbers)
	{
		String fibonacciNumbersAsString = "";

		for (int count = 0; count < fibonacciNumbers.length; count++)
		{
			if (count != fibonacciNumbers.length - 1)
			{
				fibonacciNumbersAsString += fibonacciNumbers[count] + ", ";

				if (count % 10 == 0 && count != 0)
				{
					fibonacciNumbersAsString += "\n";
				}
			} else
			{
				fibonacciNumbersAsString += fibonacciNumbers[count];
			}
		}
		return fibonacciNumbersAsString;
	}
}
