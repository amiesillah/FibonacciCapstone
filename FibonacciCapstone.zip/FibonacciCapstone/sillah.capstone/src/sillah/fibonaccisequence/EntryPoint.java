package sillah.fibonaccisequence;

public class EntryPoint
{

	public static void main(String[] args)
	{
		new FibonacciSequence();

	}

}
